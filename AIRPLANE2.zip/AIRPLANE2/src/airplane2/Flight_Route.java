/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Flight_Route {
    private Airport source;
    private Airport destination;

    // Constructor
    public Flight_Route(Airport source, Airport destination) {
        this.source = source;
        this.destination = destination;
    }

    // Getter for source
    public Airport getSource() {
        return source;
    }

    // Setter for source
    public void setSource(Airport source) {
        this.source = source;
    }

    // Getter for destination
    public Airport getDestination() {
        return destination;
    }

    // Setter for destination
    public void setDestination(Airport destination) {
        this.destination = destination;
    }    

    @Override
    public String toString() {
        return "Flight Route{" + "Source: " + source + ", Destination: " + destination + '}';
    }
}
