/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Aeroplane {
    private String planeNumber;
    private Pilot pilot;
    private Air_Hostess airHostess;

    // Constructor
    public Aeroplane(String planeNumber, Pilot pilot, Air_Hostess airHostess) {
        this.planeNumber = planeNumber;
        this.pilot = pilot;
        this.airHostess = airHostess;
    }

    // Getter for planeNumber
    public String getPlaneNumber() {
        return planeNumber;
    }

    // Setter for planeNumber
    public void setPlaneNumber(String planeNumber) {
        this.planeNumber = planeNumber;
    }

    // Getter for driver
    public Pilot getPilot() {
        return pilot;
    }

    // Setter for driver
    public void setPilot(Pilot pilot) {
        this.pilot = pilot;
    }

    // Getter for busHostess
    public Air_Hostess getAirHostess() {
        return airHostess;
    }

    // Setter for busHostess
    public void setAirHostess(Air_Hostess airHostess) {
        this.airHostess = airHostess;
    }

    @Override
    public String toString() {
        return "Aeroplane{" + "planeNumber=" + planeNumber + ", pilot=" + pilot + ", airHostess=" + airHostess.getName() + '}';
    }
    
    
}
