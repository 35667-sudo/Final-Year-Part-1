/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Employee {
    private String name;
    private String telNo;
    private int cnic;

    // Constructor
    public Employee(String name, String telNo, int cnic) {
        this.name = name;
        this.telNo = telNo;
        this.cnic = cnic;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return telNo;
    }

    public void setPhoneNumber(String telNo) {
        this.telNo = telNo;
    }

    public int getCnic() {
        return cnic;
    }

    public void setCnic(int cnic) {
        this.cnic = cnic;
    }

    @Override
    public String toString() {
        return "Employee{" + "Name: " + name + ", Tel: " + telNo + ", CNIC: " + cnic + '}';
    }
    
}
