/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Air_Hostess extends Employee {


    public Air_Hostess(String name, String telNo, int cnic) {
        super(name, telNo, cnic);
    }

    @Override
    public String toString() {
        return "Air Hostess{" + "Name: " + super.getName() + ", Tel: " + super.getPhoneNumber() + ", CNIC: " + super.getCnic() + '}';
    }
}
