/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package airplane2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class AIRPLANE2 {

    public static void main(String[] args) {
        ArrayList<Airport> airportList = new ArrayList<>();
        ArrayList<Aeroplane> aeroplaneList = new ArrayList<>();
        ArrayList<Flight_Route> flightRouteList = new ArrayList<>();
        ArrayList<Flight> flightList = new ArrayList<>();
        ArrayList<Pilot> pilotList = new ArrayList<>();
        ArrayList<Air_Hostess> airHostessList = new ArrayList<>();
        ArrayList<Customer> customerList = new ArrayList<>();
        ArrayList<Admin> adminList = new ArrayList<>();
        ArrayList<Ticket> ticketList = new ArrayList<>();

        //For demostrating purpose hardcoding the data in arrayList
        Admin admin1 = new Admin("admin1", "1234", 0123);
        Admin admin2 = new Admin("admin2", "1234", 0123);
        Admin admin3 = new Admin("admin3", "1234", 0123);
        adminList.add(admin1);
        adminList.add(admin2);
        adminList.add(admin3);

        Pilot pilot1 = new Pilot("PILOT1", "1234", 123);
        Pilot pilot2 = new Pilot("PILOT2", "1234", 123);
        Pilot pilot3 = new Pilot("PILOT3", "1234", 123);
        pilotList.add(pilot1);
        pilotList.add(pilot2);
        pilotList.add(pilot3);

        Air_Hostess ah1 = new Air_Hostess("AirHostess1", "1234", 123);
        Air_Hostess ah2 = new Air_Hostess("AirHostess2", "1234", 123);
        Air_Hostess ah3 = new Air_Hostess("AirHostess3", "1234", 123);
        airHostessList.add(ah1);
        airHostessList.add(ah2);
        airHostessList.add(ah3);

        Airport airport1 = new Airport("AIRPORT1", "ISB", "123");
        Airport airport2 = new Airport("AIRPORT2", "LHR", "123");
        airportList.add(airport1);
        airportList.add(airport2);

        Aeroplane aeroplane1 = new Aeroplane("123", pilot1, ah1);
        Aeroplane aeroplane2 = new Aeroplane("456", pilot2, ah2);
        Aeroplane aeroplane3 = new Aeroplane("789", pilot3, ah3);
        aeroplaneList.add(aeroplane1);
        aeroplaneList.add(aeroplane2);
        aeroplaneList.add(aeroplane3);

        Flight_Route flightRoute1 = new Flight_Route(airport1, airport2);
        Flight_Route flightRoute2 = new Flight_Route(airport2, airport1);
        flightRouteList.add(flightRoute1);
        flightRouteList.add(flightRoute2);

        Flight flight1 = new Flight(aeroplane1, flightRoute1, 2, 5);
        Flight flight2 = new Flight(aeroplane1, flightRoute2, 5, 2);
        Flight flight3 = new Flight(aeroplane2, flightRoute1, 4, 7);
        Flight flight4 = new Flight(aeroplane2, flightRoute2, 7, 4);

        flightList.add(flight1);
        flightList.add(flight2);
        flightList.add(flight3);
        flightList.add(flight4);

        Customer c1 = new Customer("c1", 18, "123");
        Customer c2 = new Customer("c2", 20, "123");
        customerList.add(c1);
        customerList.add(c2);

        //TICKET KO BHI INITIALIZE KAR KE ADD KARNA HAI
        Login login = new Login();
        Admin admin = null;
        Customer customer = null;

        System.out.println("=> Welcome to AirPlane Ticket Reservation System\n");

        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        do {
            System.out.println("==> YOU ARE!\n");
          
            System.out.println("\t1 - Customer");
            System.out.println("\t2 - Exit");
            System.out.print("\nEnter your choice: ");
            int userType = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (userType) {
              

                case 1:
                    Boolean customerLogin = false;
                    int choice;
                    do {
                        // Sign in as Customer
                        if (customerList.isEmpty()) {
                            System.out.println("\n==> CUSTOMER SIGNUP:");
                            login.signUp(true, customerList, false, adminList);
                        }

                        if (!customerLogin) {
                            System.out.println("\n==> CUSTOMER LOGIN:");
                            System.out.print("\n\tEnter your Name: ");
                            String customerName = scanner.nextLine();
                            int customerIndex = login.logIn(customerName, customerList, "", null);

                            if (customerIndex == -1) {
                                System.out.println("Invalid Name, try again.\n");
                                break;
                            }

                            customer = customerList.get(customerIndex);
                            customerLogin = true;
                        }

                        System.out.println("==> Customer Interface\n");
                        System.out.println("\t1 - Book a Flight");
                        System.out.println("\t2 - Display Ticket");
                        System.out.println("\t3 - To go Back\n");
                        System.out.print("\tEnter your choice: ");
                        choice = scanner.nextInt();
                        scanner.nextLine();

                        switch (choice) {
                            case 1:
                                customer.bookFlight(customer, ticketList, flightList, flightRouteList);
                                break;
                            case 2:
                                customer.displayTickets(customer, ticketList);
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("\nInvalid choice. Please choose a valid option.\n");
                        }
                    } while (choice != 3);
                    break;

                case 2:
                    exit = true;
                    System.out.println("\nGoodbye!\n");
                    break;

                default:
                    System.out.println("Invalid choice. Please select a valid user type.");
            }
        } while (!exit);

        // Close the scanner when done
        scanner.close();
    }
}
