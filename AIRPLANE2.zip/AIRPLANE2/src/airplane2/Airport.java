/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Airport {
    private String stationName;
    private String city;
    private String contactNo;

    // Constructor
    public Airport(String stationName, String city, String contactNo) {
        this.stationName = stationName;
        this.city = city;
        this.contactNo = contactNo;
    }

    // Getter for stationName
    public String getStationName() {
        return stationName;
    }

    // Setter for stationName
    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    // Getter for city
    public String getCity() {
        return city;
    }

    // Setter for city
    public void setCity(String city) {
        this.city = city;
    }

    // Getter for contactNo
    public String getContactNo() {
        return contactNo;
    }

    // Setter for contactNo
    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    @Override
    public String toString() {
        return "Airport{" + "Station: " + stationName + ", City: " + city + ", Tel: " + contactNo + '}';
    }
    
    
}
