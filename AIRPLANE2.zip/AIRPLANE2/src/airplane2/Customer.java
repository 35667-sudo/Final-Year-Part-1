/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Customer {

    private String name;
    private int age;
    private String telNo;

    public Customer(String name, int age, String telNo) {
        this.name = name;
        this.age = age;
        this.telNo = telNo;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Setter for age
    public void setAge(int age) {
        this.age = age;
    }

    // Getter for contactInfo
    public String gettelNo() {
        return telNo;
    }

    // Setter for contactInfo
    public void settelNo(String telNo) {
        this.telNo = telNo;
    }

    public void bookFlight(Customer p1, ArrayList<Ticket> ticketList, ArrayList<Flight> flightList, ArrayList<Flight_Route> flightRouteList) {
        Scanner scanner = new Scanner(System.in);

        // Check if there are routes available
        if (flightRouteList.isEmpty()) {
            System.out.println("\nNo flight routes available. Please create routes first.\n");
            return;
        }
        
        System.out.println("\n==> Booking a Flight");
        
        // Display available flight routes
        System.out.println("\n\tAvailable Flight Routes:");
        for (int i = 0; i < flightRouteList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - From " + flightRouteList.get(i).getSource().getStationName() + " To " + flightRouteList.get(i).getDestination().getStationName());
        }

        //Select Route
        System.out.print("\n\tSelect a Flight Route: ");
        int selectedRouteIndex = scanner.nextInt();
        selectedRouteIndex = selectedRouteIndex-1;
        System.out.println(selectedRouteIndex);
        // Check if the selected route index is valid - need to remove
        if (selectedRouteIndex < 0 || selectedRouteIndex > flightRouteList.size()) {
            System.out.println("\nInvalid route selection.\n");
            return;
        }

        Flight_Route selectedFlightRoute = flightRouteList.get(selectedRouteIndex);

        // Display schedules for the selected route
        System.out.println("\n\tFlight - From " + selectedFlightRoute.getSource().getStationName() + " To " + selectedFlightRoute.getDestination().getStationName() + ":\n");

        //Show schedual based on Route
        for (int i = 0; i < flightList.size(); i++) {
            if (flightList.get(i).getRoute().equals(selectedFlightRoute)) {
                System.out.println("\t\t"+ (i + 1) + " - Plane No: " + flightList.get(i).getBus().getPlaneNumber() + ", Departure Time: " + flightList.get(i).getDepartureTime() + ", Arrival Time: " + flightList.get(i).getArrivalTime());
            }
        }

        //Selecting Schedule
        System.out.print("\n\tSelect a Flight: ");
        int selectedFlightId = scanner.nextInt();
        selectedFlightId--;

        // Get Selected Schedule
        Flight selectedFlight = flightList.get(selectedFlightId);

        if (selectedFlight == null) {
            System.out.println("\nInvalid flight selection.\n");
            return;
        }
        
        int ticketPrice = 0; // Initialize the ticket price
        do{
            System.out.println("\n==> SEAT CLASS:\n");
            System.out.println("\t1 - Business Class");
            System.out.println("\t2 - First Class");
            System.out.println("\t3 - Economy Class\n");
            System.out.print("\tSelect Class: ");
            int classChoice = scanner.nextInt();

            switch (classChoice) {
                case 1:
                    ticketPrice = 50000;
                    break;
                case 2:
                    ticketPrice = 25000;
                    break;
                case 3:
                    ticketPrice = 1000;
                    break;
                default:
                    System.out.println("\nInvalid class choice.\n");
                    break;
            }
        }while(ticketPrice == 0);

        int seatNum = ticketList.size() + 1;

        // Create a new Ticket object
        Ticket ticket = new Ticket(p1, selectedFlight, seatNum, ticketPrice);

        // Add the ticket to the ticketList
        ticketList.add(ticket);

        System.out.println("\n**************************************************");
        System.out.println("*                AEROPLANE TICKET DETAILS        *");
        System.out.println("**************************************************");
        System.out.println("Name: " + ticket.getCustomer().getName());
        System.out.println("Plane No: " + ticket.getFlight().getBus().getPlaneNumber());
        System.out.println("Flight Route: " + ticket.getFlight().getRoute().getSource().getStationName() + " to " + ticket.getFlight().getRoute().getDestination().getStationName());
        System.out.println("Flight Time: " + ticket.getFlight().getDepartureTime() + " to " + ticket.getFlight().getArrivalTime());
        System.out.println("Seat No: " + ticket.getSeatNumber());
        System.out.println("Price: " + ticket.getPrice() + "rs.");
        System.out.println("**************************************************\n");
        
       
//        SmsSender sendSms = new SmsSender();
//        sendSms.senSms(ticket);
    }

    public void displayTickets(Customer customer, ArrayList<Ticket> ticketList) {
        System.out.println("\nTickets for Passenger: " + customer.getName() + "\n");
        boolean isFound = false;

        for (Ticket ticket : ticketList) {
            if (ticket.getCustomer().equals(customer)) {
//                Flight schedule = ticket.getFlight();
//                Flight_Route route = schedule.getRoute();
                
                System.out.println("\n**************************************************");
                System.out.println("*                AEROPLANE TICKET DETAILS        *");
                System.out.println("**************************************************");
                System.out.println("Name: " + ticket.getCustomer().getName());
                System.out.println("Plane No: " + ticket.getFlight().getBus().getPlaneNumber());
                System.out.println("Flight Route: " + ticket.getFlight().getRoute().getSource().getStationName() + " to " + ticket.getFlight().getRoute().getDestination().getStationName());
                System.out.println("Flight Time: " + ticket.getFlight().getDepartureTime() + " to " + ticket.getFlight().getArrivalTime());
                System.out.println("Seat No: " + ticket.getSeatNumber());
                System.out.println("Price: " + ticket.getPrice() + "rs.");
                System.out.println("**************************************************\n");
        
                isFound = true;
            }
        }

        if (!isFound) {
            System.out.println("\nNo tickets found for Passenger: " + customer.getName() + "\n");
        }
    }

    @Override
    public String toString() {
        return "Customer{" + "Name: " + name + ", Age: " + age + ", Tel: " + telNo + '}';
    }
    
    
}
