/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Ticket {

    private Customer customer;
    private Flight flight;
    private int price = 1000;
    private int seatNumber = 0;

    // Constructor
    public Ticket(Customer customer, Flight flight, int seatNumber, int price) {
        this.customer = customer;
        this.flight = flight;
        this.seatNumber = seatNumber;
        this.price = price;
    }

    // Getter for passenger
    public Customer getCustomer() {
        return customer;
    }

    // Setter for passenger
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // Getter for schedule
    public Flight getFlight() {
        return flight;
    }

    // Setter for schedule
    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    // Getter for price
    public int getPrice() {
        return price;
    }

    // Setter for price
    public void setPrice(int price) {
        this.price = price;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    @Override
    public String toString() {
        return "Ticket{" + "Customer: " + customer.toString() + "\n\t" +
                flight.toString() + "\n\t" +
                "Price: " + price + ", Seat Number: " + seatNumber + '}';
    }

}
