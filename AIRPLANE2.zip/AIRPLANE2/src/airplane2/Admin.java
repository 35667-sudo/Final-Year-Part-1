/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Admin extends Employee {

    public Admin(String name, String telNo, int cnic) {
        super(name, telNo, cnic);

    }
    
    public void createPilot(ArrayList<Pilot> pilotList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n==> CREATING PILOT");
        System.out.print("\n\tEnter Pilot Name: ");
        String driverName = scanner.nextLine();

        System.out.print("\tEnter Pilot CNIC: ");
        int driverCnic = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("\tEnter Pilot Tel: ");
        String telNo = scanner.nextLine();

        Pilot pilot = new Pilot(driverName, telNo, driverCnic);
        pilotList.add(pilot);

        System.out.println("\n--> Pilot Created Successfully!\n");
    }
     
    public void createAirHostess(ArrayList<Air_Hostess> airHostessList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n==> CREATING AIR HOSTESS");
        System.out.print("\n\tEnter Hostess Name: ");
        String hostessName = scanner.nextLine();

        System.out.print("\tEnter Hostess CNIC: ");
        int hostessCnic = scanner.nextInt();
        scanner.nextLine();

        System.out.print("\tEnter Hostess Tel: ");
        String telNo = scanner.nextLine();

        Air_Hostess airHostess = new Air_Hostess(hostessName, telNo, hostessCnic);
        airHostessList.add(airHostess);

        System.out.println("\n--> Air Hostess Created Successfully!\n");

    }

    public void createAirport(ArrayList<Airport> airportList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n==> CREATING AIRPORT");
        Scanner s1 = new Scanner(System.in);
        //Scanner s2 = new Scanner(System.in);////////////////////

        System.out.print("\n\tEnter Airport Name: ");
        String stationName = s1.nextLine();

        System.out.print("\tEnter City: ");
        String city = s1.nextLine();

        System.out.print("\tEnter Tel: ");
        String telNo = s1.nextLine();

        Airport airport = new Airport(stationName, city, telNo);
        airportList.add(airport);

        System.out.println("\n--> Airport Created Successfully!\n");
    }

    public void createAeroplane(ArrayList<Aeroplane> aeroplaneList, ArrayList<Pilot> pilotList, ArrayList<Air_Hostess> airHostessList) {
        Scanner scanner = new Scanner(System.in);

        if (pilotList.isEmpty() || airHostessList.isEmpty()) {
            System.out.println("\nPlease create at least one pilot and one air hostess before creating a plane.\n");
            return;
        }

        System.out.println("\n==> CREATING AEROPLANE");
        System.out.print("\n\tEnter Aeroplane Number: ");
        String busNumber = scanner.nextLine();

        // Prompt admin to select a Pilot
        System.out.println("\n\tPILOT LIST:");

        for (int i = 0; i < pilotList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - " + pilotList.get(i).getName());
        }
        System.out.print("\n\tSelect a Pilot:");
        int selectedPilotIndex = scanner.nextInt() - 1;

        // Prompt admin to select a Air_Hostess
        System.out.println("\n\tAEROPLANE LIST:");

        for (int i = 0; i < airHostessList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - " + airHostessList.get(i).getName());
        }
        System.out.print("\n\tSelect Air Hostess:");
        int selectedHostessIndex = scanner.nextInt() - 1;

        Aeroplane plane = new Aeroplane(busNumber, pilotList.get(selectedPilotIndex),airHostessList.get(selectedHostessIndex) );
        plane.setPilot(pilotList.get(selectedPilotIndex));
        plane.setAirHostess(airHostessList.get(selectedHostessIndex));
        aeroplaneList.add(plane);

        System.out.println("\n--> Aeroplane Created Successfully!\n");
    }

    public void createFlightRoute(ArrayList<Flight_Route> flighRouteList, ArrayList<Airport> airportList) {
        Scanner scanner = new Scanner(System.in);

        if (airportList.size() < 2) {
            System.out.println("\nPlease create at least two airports before creating a flight.\n");
            return;
        }

        System.out.println("\n==> CREATING FLIGHT ROUTE");

        // Prompt admin to select a source Airport
        System.out.println("\n\tAIRPORT LIST:");

        for (int i = 0; i < airportList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - " + airportList.get(i).getStationName());
        }
        System.out.print("\n\tSelect the Source Airport: ");
        int sourceIndex = scanner.nextInt() - 1;

        // Prompt admin to select a destination Airport //SHOW ONLY THE UNSELECTED
        System.out.println("\n\tAIRPORT LIST:");

        for (int i = 0; i < airportList.size(); i++) {
            if(i != sourceIndex){
                System.out.println("\t\t"+(i + 1) + " - " + airportList.get(i).getStationName());
            }
        }
        System.out.print("\n\tSelect the Destination Airport: ");
        int destinationIndex = scanner.nextInt() - 1;

//        scanner.nextLine(); // Consume the newline character

        Flight_Route route = new Flight_Route(airportList.get(sourceIndex), airportList.get(destinationIndex));
        flighRouteList.add(route);

        System.out.println("\n--> Flight Route Created Successfully!\n");
    }

    public void createFlight(ArrayList<Flight> flightList, ArrayList<Aeroplane> aeroplaneList, ArrayList<Flight_Route> flightRouteList) {
        Scanner scan1 = new Scanner(System.in);

        if (aeroplaneList.isEmpty() || flightRouteList.isEmpty()) {
            System.out.println("\nPlease create at least one aeroplane and one flight route before creating a flight.\n");
            return;
        }

        System.out.println("\n==> CREATING A FLIGHT");

        // Prompt admin to select a Aeroplane
        System.out.println("\n\tAEROPLANE LIST:");

        for (int i = 0; i < aeroplaneList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - " + aeroplaneList.get(i).getPlaneNumber());
        }
        
        System.out.print("\n\tSelect a Aeroplane: ");
        int aeroplaneIndex = scan1.nextInt() - 1;

        // Prompt admin to select a Flight_Route
        System.out.println("\n\tFLIGHT ROUTE List:");

        for (int i = 0; i < flightRouteList.size(); i++) {
            System.out.println("\t\t"+(i + 1) + " - From " + flightRouteList.get(i).getSource().getStationName() + " to " + flightRouteList.get(i).getDestination().getStationName());
        }
        System.out.print("\n\tSelect a Flight Route: ");

        int flightRouteIndex = scan1.nextInt() - 1;

        System.out.print("\n\tEnter Departure Time: ");
        int departureTime = scan1.nextInt();
        
        System.out.print("\tEnter Arrival Time: ");
        int arrivalTime = scan1.nextInt();

        Flight schedule = new Flight(aeroplaneList.get(aeroplaneIndex), flightRouteList.get(flightRouteIndex), departureTime, arrivalTime);
        flightList.add(schedule);

        System.out.println("\n--> Aeroplane Schedule Created Successfully!\n");
    }

    @Override
    public String toString() {
        return "Admin{" + "Name: " + super.getName() + ", Tel: " + super.getPhoneNumber() + ", CNIC: " + super.getCnic() + '}';
    }
    
    
}
