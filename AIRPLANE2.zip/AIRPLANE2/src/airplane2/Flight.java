/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Flight {
    private Aeroplane aeroplane;
    private Flight_Route route;
    private int departureTime;
    private int arrivalTime;

    // Constructor
    public Flight(Aeroplane bus, Flight_Route route, int departureTime, int arrivalTime) {
        this.aeroplane = bus;
        this.route = route;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
    }

    // Getter for bus
    public Aeroplane getBus() {
        return aeroplane;
    }

    // Setter for bus
    public void setBus(Aeroplane bus) {
        this.aeroplane = bus;
    }

    // Getter for route
    public Flight_Route getRoute() {
        return route;
    }

    // Setter for route
    public void setRoute(Flight_Route route) {
        this.route = route;
    }

    // Getter for departureTime
    public int getDepartureTime() {
        return departureTime;
    }

    // Setter for departureTime
    public void setDepartureTime(int departureTime) {
        this.departureTime = departureTime;
    }

    // Getter for arrivalTime
    public int getArrivalTime() {
        return arrivalTime;
    }

    // Setter for arrivalTime
    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    @Override
    public String toString() {
        return "Flight{" + "Aeroplane: " + aeroplane.getPlaneNumber() + ", Route: " + route.getSource() + " TO"  + route.getDestination() + ", Departure Time=" + departureTime + ", Arrival Time=" + arrivalTime + '}';
    }
    
}
