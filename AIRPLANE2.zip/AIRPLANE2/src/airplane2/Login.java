/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airplane2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASFANDYAR NAEEM
 */
public class Login {
    public void signUp(boolean customer, ArrayList<Customer> customerList, boolean admin, ArrayList<Admin>adminList){
        Scanner scanner = new Scanner(System.in);
        if(customer == true){//CUSTOMER SIGNUP

            System.out.print("\n\tEnter your Name: ");
            String customerName = scanner.nextLine();

            System.out.print("\tEnter your Age: ");
            int customerAge = scanner.nextInt();
            scanner.nextLine();

            System.out.print("\tEnter your Tel: ");
            String customerTel = scanner.nextLine();
            Customer c1 = new Customer(customerName, customerAge, customerTel);
            customerList.add(c1);

            System.out.println("\n-->Customer SignUp Successfull!");
        }
        else if(admin == true){//ADMIN SIGNUP

            System.out.print("\n\tEnter your Name: ");
            String adminName = scanner.nextLine();

            System.out.print("\tEnter your CNIC: ");
            int adminCnic = scanner.nextInt();
            scanner.nextLine();

            System.out.print("\tEnter your Tel: ");
            String adminTel = scanner.nextLine();
            Admin a1 = new Admin(adminName, adminTel, adminCnic);
            adminList.add(a1);

            System.out.println("\n--> Admin SignUp Successfull!");
        }
    }

    public int logIn(String customer, ArrayList<Customer> customerList, String admin, ArrayList<Admin>adminList){
        if(customer == ""){//ADMIN Login Validation
            if(adminList.isEmpty()){
                System.out.println("\nAdmin List is empty\n");
                return -1;
            }
            else{
                for(int i = 0; i < adminList.size(); i++){

                    if(adminList.get(i).getName().equals(admin)){
                        System.out.println("\n--> Sign-in Successfull, Welcom Mr. "+ adminList.get(i).getName()+"\n");
                        return i;
                    }
                }
                System.out.println("\nNo, Admin in the List\n");
                return -1;
            }
                        

        }
        else if(admin == ""){//CUSTOMER Login Validation
            if(customerList.isEmpty()){
                System.out.println("\nCustomer List is empty\n");
                return -1;
            }
            else{
                for(int i=0;i<customerList.size();i++){
                    if(customerList.get(i).getName().equals(customer)){
                        System.out.println("\n--> Sign-in Successfull, Welcom Mr. "+ customerList.get(i).getName()+"\n");
                        return i;
                    }
                }
                System.out.println("\nNo, Customer in the List\n");
                return -1;
            }
        }
        System.out.println("\nCheck Login Parameters!\n");
        return -1;
    }
}
